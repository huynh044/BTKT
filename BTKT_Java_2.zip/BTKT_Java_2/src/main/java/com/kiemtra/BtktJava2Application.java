package com.kiemtra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BtktJava2Application {

	public static void main(String[] args) {
		SpringApplication.run(BtktJava2Application.class, args);
	}

}
