package com.kiemtra.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "table_user")
public class User {
    @Id
    private String email;
    private String name;
}

